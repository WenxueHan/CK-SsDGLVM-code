function fval=Train(D,U,K,ini_para,dx,dy,maxIter,tol);

if isempty(maxIter)
    maxIter=500;
end
if isempty(tol)
    tol=1e-4;
end

[N,du]=size(U);

% mu0=ini_para.mu0;
P0=ini_para.P0;
C=ini_para.C;
GAMMA=ini_para.GAMMA;
A=ini_para.A;
SIGMA=ini_para.SIGMA;
B=ini_para.B;
B0=B;
mu=zeros(K,N);
mu_hat=zeros(K,N);

g=[];
V_hat=[];
V=[];
P=[]; %P1~P(N-1)
G=[];
J=[];
for n=1:N
   g=[g, {[]}];
   V_hat=[V_hat, {[]}];
   V=[V, {[]}];
   G=[G, {[]}];
   P=[P, {[]}];
   J=[J, {[]}];
end

L_old=-1e10;

for iter=1:maxIter
   %E-step
   %Forward recursion
   Cx=C(1:dx,:);
   SIGMAx=SIGMA(1:dx,1:dx);
   
   d1=D(1,:)';
   u1=U(1,:)';
   if d1(dx+dy+1)==1
       d1=d1(1:dx+dy);
       K1=P0*C'/(C*P0*C'+SIGMA);
       mu1=B0*u1+K1*(d1-C*B0*u1);
       V1=(eye(K)-K1*C)*P0;
       g1=C*B0*u1;
       G1=SIGMA+C*P0*C';
   else
       d1=d1(1:dx);
       K1=P0*Cx'/(Cx*P0*Cx'+SIGMAx);
       mu1=B0*u1+K1*(d1-Cx*B0*u1);
       V1=(eye(K)-K1*Cx)*P0;
       g1=Cx*(B0*u1);
       G1=SIGMAx+Cx*P0*Cx';
   end
   
%    if d1(dx+dy+1)==1
%        d1=d1(1:dx+dy);
%        K1=P0*C'/(C*P0*C'+SIGMA);
%        mu1=mu0+(eye(K)-K1*C)*B*u1+K1*(d1-C*mu0);
%        V1=(eye(K)-K1*C)*P0;
%        g1=C*(mu0+B*u1);
%        G1=SIGMA+C*P0*C';
%    else
%        d1=d1(1:dx);
%        K1=P0*Cx'/(Cx*P0*Cx'+SIGMAx);
%        mu1=mu0+(eye(K)-K1*C)*B*u1+K1*(d1-C*mu0);
%        V1=(eye(K)-K1*Cx)*P0;
%        g1=Cx*(mu0+B*u1);
%        G1=SIGMAx+Cx*P0*Cx';
%    end
%    
   mu(:,1)=mu1;
   V{1}=V1;
   g{1}=g1;
   G{1}=G1;
   
   for n=2:N
       dn=D(n,:)';
       un=U(n,:)';
       if dn(dx+dy+1)==1
           dn=dn(1:dx+dy);
           Pn_1=A*V{n-1}*A'+GAMMA;
           Kn=Pn_1*C'/(C*Pn_1*C'+SIGMA);
           mun=A*mu(:,n-1)+Kn*(dn-C*A*mu(:,n-1))+(eye(K)-Kn*C)*B*un;
           Vn=(eye(K)-Kn*C)*Pn_1;
           
           gn=C*A*mu(:,n-1)+C*B*un;
           Gn=C*Pn_1*C'+SIGMA;
       else
           dn=dn(1:dx);
            Pn_1=A*V{n-1}*A'+GAMMA;
            Kn=Pn_1*Cx'/(Cx*Pn_1*Cx'+SIGMAx);
            mun=A*mu(:,n-1)+Kn*(dn-Cx*A*mu(:,n-1))+(eye(K)-Kn*Cx)*B*un;
            Vn=(eye(K)-Kn*Cx)*Pn_1;
            
            gn=Cx*A*mu(:,n-1)+Cx*B*un;
            Gn=Cx*Pn_1*Cx'+SIGMAx;
       end
       P{n-1}=Pn_1;
       mu(:,n)=mun;
       V{n}=Vn;
       g{n}=gn;
       G{n}=Gn;
   
   end
   
    %Convergence Check
   pdf_dn=zeros(1,N);
   %     Log_likelihood=zeros(1,N);
   for n=1:N
       dn=D(n,:)';
       if dn(dx+dy+1)==1%label data
           dn=dn(1:dx+dy);
       else
           dn=dn(1:dx);
       end 
       pdf_dn(n)=get_normal(dn',g{n}',(G{n}));
   end
   L(iter)=sum(log(pdf_dn));
   L_new=L(iter);
   if abs(L_new-L_old)/abs(L_old)<tol
       break;
   else
       L_old=L_new;
   end
   
   %Backward recursion
   mu_hat(:,N)=mu(:,N);
   V_hat{N}=V{N};
   for n=N-1:-1:1
       Jn=V{n}*A'/P{n};
       mu_hat_n=mu(:,n)+Jn*(mu_hat(:,n+1)-A*mu(:,n))-Jn*B*U(n+1,:)';
       V_hat_n=V{n}+Jn*(V_hat{n+1}-P{n})*Jn';
       
       mu_hat(:,n)=mu_hat_n;
       V_hat{n}=V_hat_n;
       J{n}=Jn; 
   end
   %M-step
%    mu0=mu_hat(:,1)-B*U(1,:)';
%    P0=V_hat{1}+mu_hat(:,1)*mu_hat(:,1)'-(mu0+B*U(1,:)')*(mu0+B*U(1,:)')';
   B0=mu_hat(:,1)*U(1,:)/(U(1,:)'*U(1,:)+0.0001*eye(du));
   P0=V_hat{1}+mu_hat(:,1)*mu_hat(:,1)'-2*mu_hat(:,1)*U(1,:)*B0'+B0*U(1,:)'*U(1,:)*B0';
   
   sum_E_zzn_1=zeros(K,K,N-1);
   sum_E_zn_1zn_1=zeros(K,K,N-1);
   sum_E_zz=zeros(K,K,N-1);
   sum_E_zn_1z=zeros(K,K,N-1);
   sum_un_zn_1=zeros(du,K,N-1);
   sum_zn_un=zeros(K,du,N-1);
   sum_zn_1_un=zeros(K,du,N-1);
   sum_un_un=zeros(du,du,N-1);
   
   
   for n=2:N
      mu_hat_n=mu_hat(:,n);
      mu_hat_n_1=mu_hat(:,n-1);
      E_zn_zn_1=V_hat{n}*J{n-1}'+ mu_hat_n*mu_hat_n_1';
      E_zn_1_zn_1=V_hat{n-1}+mu_hat_n_1*mu_hat_n_1';
      E_zn_zn=V_hat{n}+mu_hat_n*mu_hat_n';
      E_zn_1_zn=E_zn_zn_1';
      un_zn_1=U(n,:)'*mu_hat_n_1';
      un_un=U(n,:)'*U(n,:);
      
      sum_E_zzn_1(:,:,n)=E_zn_zn_1;
      sum_E_zn_1zn_1(:,:,n)=E_zn_1_zn_1;
      sum_E_zz(:,:,n)=E_zn_zn;
      sum_E_zn_1z(:,:,n)=E_zn_1_zn;
      sum_un_zn_1(:,:,n)=un_zn_1;
      sum_zn_un(:,:,n)=mu_hat_n*U(n,:);
      sum_zn_1_un(:,:,n)=un_zn_1';
      sum_un_un(:,:,n)=un_un;
      
   end
   
   %update_A_B_GAMMA
   A=(sum(sum_E_zzn_1,3)-B*sum(sum_un_zn_1,3))/sum(sum_E_zn_1zn_1,3);
   B=(sum(sum_zn_un,3)-A*sum(sum_zn_1_un,3))/sum(sum_un_un,3);
   GAMMA=1/(N-1)*(sum(sum_E_zz,3)-2*sum(sum_E_zzn_1,3)*A'-2*sum(sum_zn_un,3)*B'...
       +A*sum(sum_E_zn_1zn_1,3)*A'+2*A*sum(sum_zn_1_un,3)*B'+B*sum(sum_un_un,3)*B');
   
   
   XX=zeros(dx,dx);
   Ez_x=zeros(K,dx);
   X_Ez=zeros(dx,K);
   E_zz=zeros(K,K);
   
   YY=zeros(dy,dy);
   Ez_y=zeros(K,dy);
   Y_Ez=zeros(dy,K);
   sum_E_zz_label=zeros(K,K); 
   num_y=0;
   
   for n=1:N
       dn=D(n,:)';
       xn=dn(1:dx);
       mu_hat_n=mu_hat(:,n);
       E_zn_zn=V_hat{n}+(mu_hat_n*mu_hat_n');
       XX=XX+(xn*xn');
       X_Ez=X_Ez+xn*mu_hat_n';
       Ez_x=Ez_x+mu_hat_n*xn';
       E_zz=E_zz+E_zn_zn;
       
       if dn(dx+dy+1)==1
          num_y=num_y+1;
          yn=dn(dx+dy,1);
          mu_hat_n=mu_hat(:,n);
          E_zn_zn_label=V_hat{n}+(mu_hat_n*mu_hat_n');
          YY=YY+(yn*yn');
          Y_Ez=Y_Ez+yn*mu_hat_n';
          Ez_y=Ez_y+mu_hat_n*yn';
          sum_E_zz_label=sum_E_zz_label+E_zn_zn_label;
       end
       
       %update_C_SIGMA
       Cx=X_Ez/E_zz;
   Cy=Y_Ez/sum_E_zz_label;
   C=[Cx;Cy];
   SIGMAx=1/N*(XX-Cx*Ez_x-X_Ez*Cx'+Cx*E_zz*Cx');
   SIGMAy=1/num_y*(YY-Cy*Ez_y-Y_Ez*Cy'+Cy*sum_E_zz_label*Cy');
   SIGMA=[SIGMAx,zeros(dx,dy);zeros(dy,dx),SIGMAy];
   end
   
end
fval.B0=B0;
fval.P0=P0;
fval.A=A;
fval.B=B;
fval.GAMMA=GAMMA;
fval.C=C;
fval.SIGMA=SIGMA;
fval.L=L;
fval.mu=mu(:,N);
fval.V=V{N};




