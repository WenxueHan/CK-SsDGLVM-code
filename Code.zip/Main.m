clc,clear
close all

load data

Dx=size(X,2);

minY=min(Y);
maxY=max(Y);

mY=mean(Y);
stdY=std(Y);

X=zscore(X);
Y=zscore(Y);

zz=[15    12    10     4     0     0     0     6];
d=round(zz(1:Dx));
h=zeros(1,Dx);
K=round(zz(Dx+1));

fval=Get_sliding_window_hwx(X,Y,d,h);
X=fval.X;
Y=fval.Y;

U = X(:,1:2);
X = X(:,3:end);

du=size(U,2);
dx=size(X,2);
dy=size(Y,2);

N=length(Y);
Nval=2000;
Ntst=1000;
Ntrn=N-Nval-Ntst;

Utst=U(N-Ntst+1:N,:);
Xtst=X(N-Ntst+1:N,:);
Ytst=Y(N-Ntst+1:N,:);

Uval=U(N-Ntst-Nval+1:N-Ntst,:);
Xval=X(N-Ntst-Nval+1:N-Ntst,:);
Yval=Y(N-Ntst-Nval+1:N-Ntst,:);

Utrn=U(1:N-Ntst-Nval,:);
Xtrn=X(1:N-Ntst-Nval,:);
Ytrn=Y(1:N-Ntst-Nval,:);

label_rate=0.1;
label_ind=round(linspace(1,Ntrn,round(label_rate*Ntrn)));
if label_ind(1)<1
    label_ind(1)=1;
end
Dtrn=[Xtrn,Ytrn];
for n=1:Ntrn
    if ismember(n,label_ind)
        Dtrn(n,dx+dy+1)=1;
    else
        Dtrn(n,dx+dy+1)=0;
    end
end

%Initialization
mu0=zeros(K,1);
P0=eye(K);
[usvd,ssvd,vsvd]=svd([Xtrn,Ytrn]');
[Busvd,Bssvd,Bvsvd]=svd([Utrn]');
C=usvd(:,1:K);
A=eye(K);
% B=rand(K,du);
B=Bssvd(:,1:K)';
GAMMA=eye(K);
vv=usvd(:,1:K)*ssvd(1:K,1:K)*vsvd(1:K,:);
SIGMA=cov(([Xtrn,Ytrn]'-vv)');

SIGMAx=SIGMA(1:dx,1:dx);
SIGMAy=SIGMA(dx+1:dx+dy,dx+1:dx+dy);
SIGMA=[SIGMAx,zeros(dx,1);zeros(1,dx),SIGMAy];

ini_para.mu0=mu0;
ini_para.P0=P0;
ini_para.C=C;
ini_para.A=A;
ini_para.B=B;
ini_para.GAMMA=GAMMA;
ini_para.SIGMA=SIGMA;

fval=Train(Dtrn,Utrn,K,ini_para,dx,dy,50,1e-3);

B0=fval.B0;
P0=fval.P0;
A=fval.A;
B=fval.B;
GAMMA=fval.GAMMA;
C=fval.C;
SIGMA=fval.SIGMA;
mun_1=fval.mu;
Vn_1=fval.V;

%Prediction
Cx=C(1:dx,:);
Cy=C(dx+1:dx+dy,:);
SIGMAx=SIGMA(1:dx,1:dx);
SIGMAy=SIGMA(dx+1:dx+dy,dx+1:dx+dy);

Yval_pre=zeros(Nval,dy);
for n=1:Nval
   xn=Xval(n,:)';
   un=Uval(n,:)';
   Pn_1=GAMMA+A*Vn_1*A';
   Kn=Pn_1*Cx'/(SIGMAx+Cx*Pn_1*Cx');
   mun=A*mun_1+Kn*(xn-Cx*A*mun_1)+(eye(K)-Kn*Cx)*B*un;
   Vn=(eye(K)-Kn*Cx)*Pn_1;
   
   Yval_pre(n,:)=Cy*mun;
   
   mun_1=mun;
   Vn_1=Vn;
end

Val_R2=1-sum((Yval-Yval_pre).^2)/sum((Yval-mean(Yval)).^2);

Ypre=zeros(Ntst,dy);
for n=1:Ntst
   xn=Xtst(n,:)';
   un=Utst(n,:)';
   Pn_1=GAMMA+A*Vn_1*A';
   Kn=Pn_1*Cx'/(SIGMAx+Cx*Pn_1*Cx');
   mun=A*mun_1+Kn*(xn-Cx*A*mun_1)+(eye(K)-Kn*Cx)*B*un;
   Vn=(eye(K)-Kn*Cx)*Pn_1;
   
   Ypre(n,:)=Cy*mun;
   
   mun_1=mun;
   Vn_1=Vn;
end

Ypre=Ypre*stdY+mY; 
Ytst=Ytst*stdY+mY;
Ypre=(Ypre-minY)/(maxY-minY);
Ytst=(Ytst-minY)/(maxY-minY);

RMSE=sqrt((Ypre-Ytst)'*(Ypre-Ytst)/Ntst);
R2=1-sum((Ytst-Ypre).^2)/sum((Ytst-mean(Ytst)).^2);




