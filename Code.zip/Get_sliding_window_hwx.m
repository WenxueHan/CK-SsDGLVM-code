function fval=Get_sliding_window_hwx(X1,Y1,d,h)

d_h=max(d+h);
[N,dx]=size(X1);

%reconstruct data set
X=[];

for i=1:dx
   Xi=[];
   for j=d(i):(d(i)+h(i))
       x=X1(d_h+1-j:N-j,i);
       Xi=[Xi,x];
   end
   X=[X,Xi];
end
Y=Y1(d_h+1:N);

fval.X=X;
fval.Y=Y;